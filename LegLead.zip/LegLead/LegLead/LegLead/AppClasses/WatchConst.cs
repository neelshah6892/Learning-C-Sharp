﻿namespace LegLead.AppClasses
{
    class WatchConst
    {
        public const string Time = "Time";
        public const string HighLow = "HighLow";
        public const string Symbol = "Symbol";
        public const string L1Strike = "L1Strike";
        public const string L1Iv = "L1Iv";
        public const string L1PrvIv = "L1PrvIv";
        public const string L1Rank = "L1Rank";
        public const string L1IVP = "L1IVP";
        public const string L1BuyOrSell = "L1BuyOrSell";
        public const string L2Strike = "L2Strike";
        public const string L2Iv = "L2Iv";
        public const string L2PrvIv = "L2PrvIv";
        public const string L2Rank = "L2Rank";
        public const string L2IVP = "L2IVP";
        public const string L2BuyOrSell = "L2BuyOrSell";
        public const string Expiry = "Expiry";
        public const string Series = "Series";
        public const string CurrAlert = "CurrAlert";
        public const string PrvAlert = "PrvAlert";
    }
}
    


